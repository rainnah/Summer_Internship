public class OrtalamaHesabi {
    public static void main(String[] args) {
        int [] yas= {21,13,56,78};
        double toplam=0;
        for (int sayi:yas ){
            toplam+=sayi;
        }
 double ortalama= toplam/yas.length;
 System.out.println("yaşlar ortalaması:"+ortalama);
    }
}

/* 
 * DAILY REPORT - DAY 4 : Today, I practiced another array problem in Java. 
 * I made a program to calculate the average of ages. 
 * I created an integer array with four different ages. 
 * Then, I used a for-each loop to find the total sum of these numbers. 
 * Finally, I divided the sum by the array length to find and print the average.
 */