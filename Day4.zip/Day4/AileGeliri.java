public class AileGeliri {
    public static void main(String[] args) {
        double [] gelir= {25.686 , 38.957 , 54.87};
        double toplam=0;
        for(double sayi:gelir){
            toplam+=sayi;
        }
double total=toplam;
System.out.println("Aile geliri:"+total);
    }
    
}

/* 
 * DAILY REPORT - DAY 4: Today, I learned about arrays in Java. 
 * I made a program to calculate the total income of a family. 
 * I created an array called gelir with double numbers inside. 
 * Then, I used a simple for-each loop to look at each number and add them together. 
 * In the end, the program prints the final total income on the screen.
 */