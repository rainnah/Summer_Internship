public class DizininEnBuyugu {
    public static void main(String[] args) {
        int[] sayilar= {74,93,43,64};
        int max= sayilar[0];
        for(int i=1 ;i< sayilar.length;i++){
            if(sayilar[i]> max){
                max= sayilar[i];
            }
        }
        System.out.println("En büyük:"+max);
    }
}

/* 
 * DAILY REPORT - DAY 4 : Today, I solved a problem about arrays. 
 * I made a program to find the biggest number in an integer array. 
 * I started by choosing the first number as the maximum number. 
 * Then, I used a for loop to check all the other numbers one by one. 
 * If a number was bigger than my maximum, I changed it, and finally printed the result.
 */