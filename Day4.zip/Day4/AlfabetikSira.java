 import java.util.Arrays;
public class AlfabetikSira {
    public static void main(String[] args) {
        String [] Alfabetik= {"R","E","Y","H","A","N","S","U","D","E"};
Arrays.sort(Alfabetik);
System.out.println(Arrays.toString(Alfabetik));
    }
}

/* 
 * DAILY REPORT - DAY 4 : Today, I worked on sorting arrays. 
 * I made a String array with my name. 
 * I used the Arrays.sort method to order these letters alphabetically. 
 * Then, I used Arrays.toString to convert the array into a clean text format. 
 * Finally, the program prints the sorted list on the screen.
 */