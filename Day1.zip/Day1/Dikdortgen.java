public class Dikdortgen {
    int x; //dik kenar
    int y; //yatay kenar
    public Dikdortgen(int x, int y ){
        this.x= x;
        this.y= y;
  }
 public int alan(){
    return x*y;
 }
public int cevre(){
    return 2* (x +y);

  }
  public static void main(String[]args){
    Dikdortgen d1= new Dikdortgen (7,9);
    System.out.println("Dikdörtgenin alanı:"+d1.alan());
    System.out.println("Dikdörtgenin çevresi:"+d1.cevre());
  }
}

/* 
 * DAILY REPORT - DAY 1: Today, I learned how to make a class in Java. 
 * I made a class called Dikdortgen. It has two variables for the sides. 
 * I wrote a constructor method to give values to these variables. 
 * Then, I wrote two simple functions to find the area and perimeter. 
 * In the main method, I created one object and printed the scores.
 */