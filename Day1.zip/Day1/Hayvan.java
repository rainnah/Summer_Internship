public class Hayvan {
    String isim;
    String tur;
    int yas;

    public Hayvan (String isim, String tur, int yas){
        this.isim= isim;
        this.tur= tur;
        this.yas= yas;
        
        }
    public static void main (String[]args){
        Hayvan h1 = new Hayvan("Hamsi","Golden",3);
        System.out.println(h1.isim +"\n"+ h1.tur +"\n"+ h1.yas);
        }
}

/* 
 * DAILY REPORT - DAY 1 : Today, I practiced making another class in Java. 
 * I created a class named Hayvan. This class has three variables for animal information. 
 * I used a constructor method to set the name, type, and age. 
 * In the main method, I created a new animal object with these details. 
 * Finally, I used System.out.println to show the information on the screen.
 */