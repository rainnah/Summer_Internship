import java.util.Scanner;

public class Tek_Cift{
    public static void main(String[]args){
        Scanner scanner= new Scanner(System.in);
        System.out.println("Sayı gir");
        int sayi = scanner.nextInt();

        if(sayi %2 ==0){
            System.out.println(sayi+"çift sayı");
        } else{
            System.out.println(sayi+"tek sayı");
        }
        scanner.close();

    }

}
    

/* 
 * DAILY REPORT - DAY 2 : Today, I studied if-else conditions in Java. 
 * I made a program to find if a number is odd or even. 
 * I used a Scanner object to get a number from the user. 
 * Then, I used the if-else blocks and the remainder operator to check the number. 
 * Finally, the program prints the result and closes the scanner.
 */