import java.util.Scanner;

public class Find_BiggestSmallest {
    public static void main(String[] args) {
       Scanner scanner= new Scanner(System.in);
       System.out.println("3 tane sayı gir");
       int s1= scanner.nextInt();
       int s2= scanner.nextInt();
       int s3= scanner.nextInt();

       int biggest= s1;
       int smallest= s1;

       if (s2> biggest){
        biggest=s2;
       }
       if (s3> biggest){
        biggest=s3;
       }

       if (s2<smallest){
        smallest= s2;
       }
       if (s3<smallest){
        smallest=s3;
       }

       System.out.println("Biggest:"+biggest);
       System.out.println("Smallest:"+smallest);

       scanner.close();
    }
}

/* 
 * DAILY REPORT - DAY 2 : Today, I practiced more if-else conditions. 
 * I wrote a program to find the biggest and smallest numbers. 
 * The program takes three numbers from the user. 
 * Then, it uses separate if blocks to compare these numbers one by one. 
 * At the end, it finds the correct results and prints them on the screen.
 */