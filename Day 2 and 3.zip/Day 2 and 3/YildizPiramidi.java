public class YildizPiramidi {
    public static void main(String[] args) {
        int n =6;
        for (int i= 1 ; i<=n ; i++) {
            for ( int s=1 ; s<=n-i ; s++ )
                System.out.print(" ");
            
            for (int j =1 ; j<=(2*i-1) ; j++) 
                System.out.print("*");

            System.out.println();
            
        }
    }
}

/* 
 * DAILY REPORT - DAY 3: Today, I studied loops in Java. 
 * I wanted to make a star pyramid on the screen. 
 * I used a main loop to control the lines of the pyramid. 
 * Inside, I wrote one loop to print spaces and another loop to print stars. 
 * After each line, I used a new line command to go down.