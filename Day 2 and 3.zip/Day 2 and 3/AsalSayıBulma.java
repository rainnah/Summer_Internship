public class AsalSayıBulma {
    public static void main(String[] args) {
        for(int i= 2; i<=100; i++){
            boolean asalmi = true;

            for (int j= 2; j<= Math.sqrt(i); j++){ //bölen bir sayı varsa kareköküne kadar olan sayılardan biri olmalıymış mutlaka , diğer sayılar için de kontrol etmemize gerek yok.
                if (i % j ==0){
                    asalmi= false ;
                    break;
                }
            }
    
        
             if (asalmi){
            System.out.println(i+"");
            }
        }
    }
}

/* 
 * DAILY REPORT - DAY 3 : Today, I wrote a program to find prime numbers up to 100. 
 * I used a main loop to check every number from 2 to 100. 
 * Inside, I used another loop to look for divisors. 
 * For efficiency, this inner loop only checks numbers up to the square root of the number. 
 * If the program finds a divisor, it stops the loop and prints only the prime numbers.
 */